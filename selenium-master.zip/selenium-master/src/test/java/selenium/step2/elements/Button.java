package selenium.step2.elements;

public interface Button extends Element {
    void click();
}
