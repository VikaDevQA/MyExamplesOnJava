package selenium.step2.elements;

public interface Element {
    boolean isDisplayed();
}
