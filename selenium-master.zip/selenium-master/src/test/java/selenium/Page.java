package selenium;

import org.openqa.selenium.WebDriver;

public interface Page {
    void init(WebDriver driver);
}
