package selenium;

public interface SearchPage extends Page {
    void search(String query);
}
